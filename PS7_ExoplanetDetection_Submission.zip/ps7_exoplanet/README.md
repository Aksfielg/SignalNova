# PS7: AI-Enabled Exoplanet Detection — ISRO BAH 2026

## What this project does
Automated pipeline that detects exoplanet transit signals in TESS astronomical
light curves using Box Least Squares plus Lomb-Scargle cross-validation,
23-feature XGBoost classification, and crowded-field vetting.

## How to run everything at once
`python run_full_pipeline.py`

## How to run step by step
```
pip install -r requirements.txt
python src/01_download.py
python src/02_preprocess.py
python src/03_bls_search.py
python src/03b_lomb_scargle.py
python src/04_crowding_check.py
python src/05_classifier.py
python src/07_validate.py
python src/08_final_report.py
streamlit run app/streamlit_app.py
python report/generate_report.py
```

## Signal classes
PLANET, ECLIPSING_BINARY, BLEND, OTHER

## Validation results
Pipeline recovers known exoplanet periods within 0.1% error on
WASP-126 b, TOI-700 d, and WASP-39 b.

## Tech stack
lightkurve, astropy, astroquery, xgboost, scikit-learn, streamlit, plotly, reportlab
